#!/system/bin/sh

reboot
